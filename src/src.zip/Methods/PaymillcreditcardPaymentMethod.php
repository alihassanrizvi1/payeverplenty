<?php

namespace Payever\Methods;

/**
 * Class paymillcreditcardPaymentMethod
 * @package Payever\Methods
 */
class PaymillcreditcardPaymentMethod extends AbstractPaymentMethod
{
    /**
     * @var string
     */
    public $methodCode = 'paymill_creditcard';
}
