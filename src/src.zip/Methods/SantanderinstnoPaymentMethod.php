<?php

namespace Payever\Methods;

/**
 * Class SantanderinstnoPaymentMethod
 * @package Payever\Methods
 */
class SantanderinstnoPaymentMethod extends AbstractPaymentMethod
{
    /**
     * @var string
     */
    public $methodCode = 'santander_installment_no';
}
