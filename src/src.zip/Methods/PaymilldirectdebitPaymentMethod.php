<?php

namespace Payever\Methods;

/**
 * Class PaymilldirectdebitPaymentMethod
 * @package Payever\Methods
 */
class PaymilldirectdebitPaymentMethod extends AbstractPaymentMethod
{
    /**
     * @var string
     */
    public $methodCode = 'paymill_directdebit';
}
