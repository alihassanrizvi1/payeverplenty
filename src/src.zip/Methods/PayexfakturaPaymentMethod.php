<?php

namespace Payever\Methods;

/**
 * Class PayexfakturaPaymentMethod
 * @package Payever\Methods
 */
class PayexfakturaPaymentMethod extends AbstractPaymentMethod
{
    /**
     * @var string
     */
    public $methodCode = 'payex_faktura';
}
