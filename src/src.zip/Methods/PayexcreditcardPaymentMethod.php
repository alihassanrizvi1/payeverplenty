<?php

namespace Payever\Methods;

/**
 * Class PayexcreditcardPaymentMethod
 * @package Payever\Methods
 */
class PayexcreditcardPaymentMethod extends AbstractPaymentMethod
{
    /**
     * @var string
     */
    public $methodCode = 'payex_creditcard';
}
