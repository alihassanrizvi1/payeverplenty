<?php

namespace Payever\Methods;

/**
 * Class SantanderfactoringdePaymentMethod
 * @package Payever\Methods
 */
class SantanderfactoringdePaymentMethod extends AbstractPaymentMethod
{
    /**
     * @var string
     */
    public $methodCode = 'santander_factoring_de';
}
