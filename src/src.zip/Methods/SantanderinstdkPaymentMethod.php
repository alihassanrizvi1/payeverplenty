<?php

namespace Payever\Methods;

/**
 * Class SantanderinstdkPaymentMethod
 * @package Payever\Methods
 */
class SantanderinstdkPaymentMethod extends AbstractPaymentMethod
{
    /**
     * @var string
     */
    public $methodCode = 'santander_installment_dk';
}
