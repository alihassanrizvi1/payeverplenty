<?php

namespace Payever\Methods;

/**
 * Class SantanderinvoicenoPaymentMethod
 * @package Payever\Methods
 */
class SantanderinvoicenoPaymentMethod extends AbstractPaymentMethod
{
    /**
     * @var string
     */
    public $methodCode = 'santander_invoice_no';
}
