<?php

namespace Payever\Methods;

/**
 * Class SantanderinvoicedePaymentMethod
 * @package Payever\Methods
 */
class SantanderinvoicedePaymentMethod extends AbstractPaymentMethod
{
    /**
     * @var string
     */
    public $methodCode = 'santander_invoice_de';
}
